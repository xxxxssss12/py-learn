#!/bin/bash

CURRENT_PATH=$(cd `dirname $0`; pwd)

/bin/bash "$CURRENT_PATH/stop.sh"
/bin/bash "$CURRENT_PATH/start.sh"
