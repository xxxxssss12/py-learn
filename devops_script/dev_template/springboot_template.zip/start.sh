#!/bin/bash

ROOT_PATH={{APP_ROOT_PATH}}
CURRENT_PATH=$(cd `dirname $0`; pwd)
PARENT_PATH=$(cd `dirname $0`; cd ..; pwd)
CURRENT_SERVICE_NAME=$(echo ${CURRENT_PATH} | awk -F '/' '{print $(NF)}')

# USE THOSE VARIABLE
GC_LOG_PATH=${CURRENT_PATH}/logs/${CURRENT_SERVICE_NAME}-gcdetail.log
COMMON_CONFIG_PATH=${PARENT_PATH}
CONFIG_PATH=${CURRENT_PATH}/config
JAR_PATH=${CURRENT_PATH}/jar
LOG_PATH=${CURRENT_PATH}/logs

## MODIFY FOLLOWING LINES
EXECUT_JAR="{{JAR}}"
PARAMETER="
{{PARAMETER}}
"
## -javaagent:/root/soft/apache-skywalking-apm-bin/agent/skywalking-agent.jar
## STOP MODIFY
echo ${PARAMETER}

nohup java -jar ${PARAMETER} > ${LOG_PATH}/${CURRENT_SERVICE_NAME}.log 2>&1 &
echo ${CURRENT_SERVICE_NAME} start over!
