#!/bin/bash
set -e
echo "stop start..."
CURRENT_DIR=$(cd $(dirname $0); pwd)
PROC_CNT=`ps -ef|grep $CURRENT_DIR|grep -v grep| wc -l`
PID=`ps ax | grep $CURRENT_DIR | grep java | head -1 | awk '{print $1}'`

CNT=10
while [[ -n "$PID" && $CNT -gt 0 ]]
do
  PID=$(ps ax | grep $CURRENT_DIR | grep java | head -1 | awk '{print $1}')
  if [ -n "$PID" ]
  then
    echo "kill proccess $PID.....last try $CNT time"
    kill $PID
    sleep 2
  fi
  CNT=`expr $CNT - 1`
done

if [ -n "$PID" ]
then
  echo "force kill proccess $PID"
  kill -9 $PID
fi

if [ -n "$PID" ]
then
  echo "stop fail!$PID"
else
  echo "stop success..."
fi
